﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using AccesoDatos;
using System.Data;
using System.Net;
using System.Xml.Linq;

namespace Entidades
{
    public class Funciones
    {
        
        private DBManager dbManager = null;


        public int RegistraLlamada(Iframe iframe, DatosReporte DatosReporte)
        {
            int llamadaRegistrada = 0;
            try
            {
                using (dbManager = new DBManager("Server=cmv8049;Database=une;User Id=Presence;Password=Abcde1"))
                {
                    dbManager.Open();
                    dbManager.CreateParameters(9);
                    dbManager.AddParameters(0, "@vContactID", iframe.vContactID);
                    dbManager.AddParameters(1, "@vCallType", iframe.vCallType);
                    dbManager.AddParameters(2, "@vPhone", iframe.vPhone);
                    dbManager.AddParameters(3, "@vServiceID", iframe.vServiceID);
                    dbManager.AddParameters(4, "@vAgenteID", iframe.vAgenteID);
                    dbManager.AddParameters(5, "@folio", DatosReporte.folio);
                    dbManager.AddParameters(6, "@moduloAtencion", DatosReporte.moduloAtencion);
                    dbManager.AddParameters(7, "@nombreAgente", iframe.AgenteAtiende);
                    if(DatosReporte.moduloAtencion == Enumeraciones.CAT_MODULO_ATENCION.FRAUDES)
                    {
                        dbManager.AddParameters(8, "@idSeguimiento", iframe.vID_CC_Fraudes);
                    }
                    else if (DatosReporte.moduloAtencion == Enumeraciones.CAT_MODULO_ATENCION.CALL_CENTER)
                    {
                        dbManager.AddParameters(8, "@idSeguimiento", iframe.vID_Fraudes_CC);
                    }
                    

                    dbManager.ExecuteReader(CommandType.StoredProcedure, "SP_CALLCENTER_REGISTRAR_LLAMADA");
                    if (dbManager.DataReader.Read())
                    {
                        llamadaRegistrada = Convert.ToInt32(dbManager.DataReader["estatus"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return llamadaRegistrada;

        }

        public string GenerarUrlLlamada(string nombre, string telefono)
        {
            string urlLlamada = "";
            try
            {
                using (dbManager = new DBManager("Server=cmv8049;Database=une;User Id=Presence;Password=Abcde1"))
                {
                    dbManager.Open();
                    dbManager.CreateParameters(2);
                    dbManager.AddParameters(0, "@name", nombre);
                    dbManager.AddParameters(1, "@phone", telefono);
                    

                    dbManager.ExecuteReader(CommandType.StoredProcedure, "SP_FRAUDES_GENERAR_URL_LLAMADA");
                    if (dbManager.DataReader.Read()){
                        if (Convert.ToInt32(dbManager.DataReader["estatus"].ToString()) == 200)
                        {
                            urlLlamada = dbManager.DataReader["url_llamada"].ToString();
                        }
                    }
                        
                    /*if (dbManager.DataReader.Read())
                    {
                        llamadaRegistrada = Convert.ToInt32(dbManager.DataReader["estatus"].ToString());
                    }*/
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return urlLlamada;

        }


        /*public string ObtenerAgente()
        {
            string urlAgente = "http://localhost:6080/GetAgentName";
            WebRequest request = WebRequest.Create(urlAgente);
            WebResponse response = request.GetResponse();
            XDocument xmlDoc = new XDocument();
            string agente = "";
            try
            {
                
                using (var sr = new System.IO.StreamReader(response.GetResponseStream()))
                {
                    
                    xmlDoc = XDocument.Parse(sr.ReadToEnd());
                    try
                    {
                        
                        //agente = xmlDoc.Descendants("AgentHTTPResponse").ToString();//Root.Element("AgentHTTPResponse").Element("Parameters").Element("AgentName").Value;//Element("AgentHTTPResponse").ToString(); //nodeElement("AgentHTTPResponse").Value;

                        var contactosAll =
                            from c in xmlDoc.Descendants("Parameters")
                            select c.Element("AgentName").Value;
                        agente = contactosAll.ToList()[0].ToString();
                    }
                    catch (Exception ex)
                    {
                        // handle if necessary
                        throw ex;
                    }
                }
            }
            catch (WebException ex)
            {
                throw ex;
                // handle if necessary    
            }

            return agente;
        }*/


        public int ActualizarRegistroLlamada(Iframe iframe, DatosReporte DatosReporte)
        {
            int llamadaRegistrada = 0;
            try
            {
                using (dbManager = new DBManager("Server=cmv8049;Database=une;User Id=Presence;Password=Abcde1"))
                {
                    dbManager.Open();
                    dbManager.CreateParameters(3);
                    dbManager.AddParameters(0, "@contactID", iframe.vContactID);
                    dbManager.AddParameters(1, "@crmFolio", DatosReporte.folioUNE);
                    dbManager.AddParameters(2, "@folioAtencion", DatosReporte.folio);
                    
                    dbManager.ExecuteReader(CommandType.StoredProcedure, "SP_CALLCENTER_ACTUALIZAR_GRABACION_DATOS");
                    if (dbManager.DataReader.Read())
                    {
                        llamadaRegistrada = Convert.ToInt32(dbManager.DataReader["estatus"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return llamadaRegistrada;

        }

    }
}
