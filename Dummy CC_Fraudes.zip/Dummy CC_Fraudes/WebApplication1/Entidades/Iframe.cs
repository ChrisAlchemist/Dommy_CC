﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Entidades
{
    
    public class Iframe
    {
        public Decimal? vContactID { get; set; }
        public int vCallType { get; set; }
        public string vPhone { get; set; }
        public string vServiceID { get; set; }
        public string vAgenteID { get; set; }
        public int vNumeroSocio { get; set; }
        public string AgenteAtiende { get; set; }
        public string LlamadaURL { get; set; }

        public string vID_CC_Fraudes { get; set; }
        
        public string vID_Fraudes_CC { get; set; }

        //public int vQCode { get; set; }
        //public String vFolio { get; set; }

    }

    public class DatosReporte
    {
        //Enumeraciones enumeraciones = new Enumeraciones();
        public Int64 folio { get; set; }
        public Enumeraciones.CAT_MODULO_ATENCION moduloAtencion { get; set; }

        public int folioUNE { get; set; }
    }
}
