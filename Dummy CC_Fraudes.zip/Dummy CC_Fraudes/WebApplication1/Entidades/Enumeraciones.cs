﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Enumeraciones
    {
        public enum CAT_MODULO_ATENCION
        {
            CALL_CENTER = 1,
            FRAUDES = 2,
            UNE = 3,
        }
    }
}
