﻿$(document).ready(function () {
    nombreAgente();
    idAgente();
});

function onClickActualizarRegistroCallCenter() {

    var iFrame = {};
    var datosReporte = {};

    iFrame.vContactID = $("#vContactID").val();
    datosReporte.folio = parseInt($("#folio").val());
    datosReporte.folioUNE = 000;

    $.ajax({
        method: "POST",
        url: rootUrl("/Registrar/ActualizarRegistroCallCenterJson"),
        data: { iframe: iFrame, datosReporte: datosReporte},
        dataType: "json",
        success: function (data) {
            if (data.estatus == 1) {
                alert("Actualizacion Correcta");
            }            
        },
        error: function (xhr, status, error) {
            alert(error);
        },
    });
}

function onClickActualizarRegistroFraudes() {

    var iFrame = {};
    var datosReporte = {};

    iFrame.vContactID = $("#vContactID").val();    
    datosReporte.folio = parseInt($("#folio").val());

    datosReporte.folioUNE = 002;

    $.ajax({
        method: "POST",
        url: rootUrl("/FraudesQA/ActualizarRegistroFraudesJson"),
        data: { iframe: iFrame, datosReporte: datosReporte },
        dataType: "json",
        success: function (data) {
            if (data.estatus == 1) {
                alert("Registro Correcto");
            }
        },
        error: function (xhr, status, error) {
            alert(error);
        },
    });
}

function openInNewTab(url) {
    var win = window.open(url, '_blank');
    win.close();
}


function onClickRealizarLlamadaFraudes() {
    
    var nombreSocio = $("#vNumeroSocio").val();
    var telefonoSocio = $("#vPhone").val();    
    //datosReporte.folio = parseInt($("#folio").val());

    $.ajax({
        method: "POST",
        url: rootUrl("/FraudesQA/RealizarLlamadaJson"),
        data: { nombre: nombreSocio, telefono: telefonoSocio },
        dataType: "json",
        success: function (data) {
            
            if (data.estatus == 200) {
                var estatus = false;
                estatus = estatusLlamada(data.urlLlamada);
                if (estatus == true) {
                    alert("Se realizo la llamada con exito");
                    openInNewTab(data.urlLlamada);
                    //onClickRegistrarLlamadaSalienteFraudes();
                }
                else {
                    alert("No se pudo realizar la llamada");
                }
                
            }
        },
        error: function (xhr, status, error) {
            alert(error);
        },
    });
}


function nombreAgente() {
    $.ajax({
        type: "GET",
        url: "http://localhost:6080/GetAgentName",
        contentType: "text/xml; charset=utf-8",        
        success: function (response) {            
            $(response).find("AgentName").each(function () {
                $("#AgenteAtiende").val($(this).text());                
            });
        },
        error: function (response,error,fail) {
            $('#result').html('failure:<br />' + response.responseText);
        }
    });
}

function idAgente() {
    $.ajax({
        type: "GET",
        url: "http://localhost:6080/GetAgentID",
        contentType: "text/xml; charset=utf-8",
        success: function (response) {
            $(response).find("AgentId").each(function () {
                $("#vAgenteID").val($(this).text());
            });
        },
        error: function (response, error, fail) {
            $('#result').html('failure:<br />' + response.responseText);
        }
    });
}


function estatusLlamada(urlLlamada) {
    var respon;
    $.ajax({
        type: "GET",
        url: urlLlamada,
        contentType: "text/xml; charset=utf-8",
        async: false,
        success: function (response) {
            $(response).find("Result").each(function () {
                if ($(this).text() == '$00000000') {
                    respon = true;
                }
            });
        },
        error: function (response, error, fail) {
            respon = true;
        }
    });
    return respon;
}

function onClickRegistrarLlamadaSalienteFraudes() {

    var iFrame = {};
    var datosReporte = {};

    iFrame.vContactID = $("#vContactID").val();
    iFrame.vCallType = $("#vCallType").val();
    iFrame.vPhone = $("#vPhone").val();
    iFrame.vServiceID = $("#vServiceID").val();
    iFrame.vAgenteID = $("#vAgenteID").val();
    iFrame.AgenteAtiende = $("#AgenteAtiende").val();

    datosReporte.folio = parseInt($("#folio").val());

    $.ajax({
        method: "POST",
        url: rootUrl("/FraudesQA/RegistroLlamadaJson"),
        data: { iframe: iFrame, datosReporte: datosReporte },
        dataType: "json",
        success: function (data) {
            if (data.estatus == 1) {
                alert("Registro Correcto");
            }
        },
        error: function (xhr, status, error) {
            alert(error);
        },
    });
}


function idSeguimientoAFraudes() {    
    var url = "http://localhost:6080/AddCallData?Key=ID_CC_Fraudes&Value=" + $("#vContactID").val();
    var win = window.open(url, '_blank');
    //win.close();
}

function idSeguimientoACallCenter() {
    var url = "http://localhost:6080/AddCallData?Key=ID_Fraudes_CC&Value=" + $("#vID_CC_Fraudes").val()+", " + $("#vContactID").val();
    var win = window.open(url, '_blank');
    //win.close();
}