﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class FraudesQAController : Controller
    {
        private Funciones funciones = new Funciones();
        // GET: FraudesQA
        public ActionResult FraudesQA(Iframe iframe)
        {
            try
            {
                //iframe.Agente = funciones.ObtenerAgente();
                //iframe.LlamadaURL = funciones.GenerarUrlLlamada(); //"http://localhost:6080/InsertOutboundRecord?ServiceId=31222&LoadId=1000&SourceId=2019120000001&Name=Pedro_Infante&Phone=931010201&Status=1&Priority=100";

                if (iframe.vContactID != null)
                {
                    DatosReporte datosReporte = new DatosReporte();
                    datosReporte.moduloAtencion = Enumeraciones.CAT_MODULO_ATENCION.FRAUDES;
                    funciones.RegistraLlamada(iframe, datosReporte);
                }

                return View(iframe);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }

        [HttpPost]
        public ActionResult RegistroLlamadaJson(Iframe iframe, DatosReporte datosReporte)
        {
            try
            {
                
                int registroExitoso;
                //string agenteRegistra = funciones.ObtenerAgente();

                datosReporte.moduloAtencion = Enumeraciones.CAT_MODULO_ATENCION.FRAUDES;

                registroExitoso = funciones.RegistraLlamada(iframe, datosReporte);
                return Json(new { estatus = registroExitoso, mensaje = "Falla al tratar obtener un prestamo." }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return new HttpStatusCodeResult(500, ex.Message);
            }
        }

        [HttpPost]
        public ActionResult RealizarLlamadaJson(string nombre, string telefono)
        {
            try
            {
                string urlLlamada = "";
                
                urlLlamada = funciones.GenerarUrlLlamada(nombre, telefono);

                return Json(new { estatus = 200, urlLlamada = urlLlamada, mensaje = "Falla al tratar de realizar llamada." }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return new HttpStatusCodeResult(500, ex.Message);
            }
        }

        public ActionResult ActualizarRegistroFraudesJson(Iframe iframe, DatosReporte datosReporte)
        {
            try
            {

                int registroExitoso;
                //string agenteRegistra = funciones.ObtenerAgente();

                datosReporte.moduloAtencion = Enumeraciones.CAT_MODULO_ATENCION.FRAUDES;

                registroExitoso = funciones.ActualizarRegistroLlamada(iframe, datosReporte);
                return Json(new { estatus = registroExitoso, mensaje = "Falla al tratar de actualizar folio." }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return new HttpStatusCodeResult(500, ex.Message);
            }
        }

    }
    
}


