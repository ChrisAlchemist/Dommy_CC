﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entidades;

namespace WebApplication1.Controllers
{
    public class RegistrarController : Controller
    {
        Funciones funciones = new Funciones();
        // GET: Registrar
        public ActionResult Registrar(Iframe iframe)
        {
            if (iframe.vContactID != null)
            {
                DatosReporte datosReporte = new DatosReporte();
                datosReporte.moduloAtencion = Enumeraciones.CAT_MODULO_ATENCION.CALL_CENTER;
                funciones.RegistraLlamada(iframe, datosReporte);
            }
            //iframe.Agente = funciones.ObtenerAgente();
            return View(iframe);
        }

        [HttpPost]
        public ActionResult ActualizarRegistroCallCenterJson(Iframe iframe, DatosReporte datosReporte)
        {
            try
            {
                Funciones funciones = new Funciones();
                int registroExitoso;
                datosReporte.moduloAtencion = Enumeraciones.CAT_MODULO_ATENCION.CALL_CENTER;

                registroExitoso = funciones.ActualizarRegistroLlamada(iframe, datosReporte);
                return Json(new { estatus = registroExitoso, mensaje = "Falla al de actualizar registro." }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return new HttpStatusCodeResult(500, ex.Message);
            }
        }
    }
}